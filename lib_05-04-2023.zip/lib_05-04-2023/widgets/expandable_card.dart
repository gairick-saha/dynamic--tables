import 'package:flutter/material.dart';

const Duration _kExpand = Duration(milliseconds: 200);

class ExpandableCard extends StatefulWidget {
  const ExpandableCard({
    Key? key,
    required this.title,
    this.titleStyle,
    required this.child,
    this.initiallyExpanded = false,
    this.onExpansionChanged,
    this.radius = BorderRadius.zero,
    this.childRadius,
    this.headerBuilder,
  }) : super(key: key);

  final String title;
  final TextStyle? titleStyle;
  final Widget child;
  final bool initiallyExpanded;
  final ValueChanged<bool>? onExpansionChanged;
  final BorderRadiusGeometry radius;
  final BorderRadiusGeometry? childRadius;

  final Widget Function(
    BuildContext context,
    String title,
    Animation<double> iconTurns,
    BorderRadiusGeometry radius,
  )? headerBuilder;

  @override
  State<ExpandableCard> createState() => _ExpandableCardState();
}

class _ExpandableCardState extends State<ExpandableCard>
    with SingleTickerProviderStateMixin {
  static final Animatable<double> _easeInTween =
      CurveTween(curve: Curves.easeIn);
  static final Animatable<double> _halfTween =
      Tween<double>(begin: 0.0, end: 0.5);

  late AnimationController _controller;
  late Animation<double> _iconTurns;
  late Animation<double> _heightFactor;

  bool _isExpanded = false;

  @override
  void initState() {
    _controller = AnimationController(duration: _kExpand, vsync: this);
    _heightFactor = _controller.drive(_easeInTween);
    _iconTurns = _controller.drive(_halfTween.chain(_easeInTween));

    _isExpanded =
        PageStorage.of(context).readState(context) ?? widget.initiallyExpanded;
    if (_isExpanded) _controller.value = 1.0;
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _handleTap() {
    setState(
      () {
        _isExpanded = !_isExpanded;
        if (_isExpanded) {
          _controller.forward();
        } else {
          _controller.reverse().then<void>((void value) {
            if (!mounted) return;
            setState(() {});
          });
        }
        PageStorage.of(context).writeState(context, _isExpanded);
      },
    );
    if (widget.onExpansionChanged != null) {
      widget.onExpansionChanged!(_isExpanded);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool closed = !_isExpanded && _controller.isDismissed;
    final BorderRadiusGeometry headerRadius = widget.radius == BorderRadius.zero
        ? BorderRadius.circular(8.0)
        : widget.radius;

    return AnimatedBuilder(
      animation: _controller.view,
      builder: (BuildContext context, Widget? child) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Builder(
              builder: widget.headerBuilder != null
                  ? (context) => widget.headerBuilder!(
                        context,
                        widget.title,
                        _iconTurns,
                        headerRadius,
                      )
                  : (context) => ListTile(
                        onTap: _handleTap,
                        minLeadingWidth: 0,
                        tileColor: _isExpanded
                            ? Colors.transparent
                            : Theme.of(context).cardColor,
                        leading: RotationTransition(
                          turns: _iconTurns,
                          child: const Icon(
                            Icons.expand_more,
                          ),
                        ),
                        horizontalTitleGap: 10,
                        title: Text(
                          widget.title,
                          style: widget.titleStyle,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: headerRadius,
                        ),
                      ),
            ),
            ClipRect(
              child: Align(
                alignment: Alignment.topLeft,
                heightFactor: _heightFactor.value,
                child: widget.headerBuilder != null
                    ? child
                    : SizedBox(
                        width: double.maxFinite,
                        child: Card(
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                            borderRadius: widget.childRadius ?? headerRadius,
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: child,
                          ),
                        ),
                      ),
              ),
            ),
          ],
        );
      },
      child: closed ? null : widget.child,
    );
  }
}
